package com.fnb.orderManagementService.kafka;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fnb.orderManagementService.dto.OrderConfirmationEvent;
import com.fnb.orderManagementService.dto.PaymentResultEvent;
import com.fnb.orderManagementService.entity.Order;
import com.fnb.orderManagementService.repository.OrderRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
@RequiredArgsConstructor
@Slf4j
public class OrderEventConsumer {

    private final OrderRepository orderRepository;
    private final OrderConfirmationProducer confirmationProducer;
    private final ObjectMapper objectMapper;

    @KafkaListener(topics = "payment-result", groupId = "order-group")
    @Transactional
    public void consumePaymentResult(ConsumerRecord<String, String> record) {
        try {
            log.info("Received payment-result event: partition={}, offset={}, key={}",
                    record.partition(), record.offset(), record.key());

            PaymentResultEvent event = objectMapper.readValue(record.value(), PaymentResultEvent.class);

            Order order = orderRepository.findByIdempotencyKey(event.getOrderId())
                    .orElse(null);

            if (order == null) {
                log.warn("Order not found for orderId={}, skipping", event.getOrderId());
                return;
            }

            String newStatus = "APPROVED".equals(event.getStatus()) ? "COMPLETED" : "PAYMENT_DECLINED";

            // Idempotent: skip if already in terminal state
            if (newStatus.equals(order.getStatus())) {
                log.info("Order {} already in status {}, skipping (replay-safe)", order.getId(), newStatus);
                return;
            }

            order.setStatus(newStatus);
            orderRepository.save(order);
            log.info("Order {} status updated to {}", order.getId(), newStatus);

            // Emit confirmation event
            OrderConfirmationEvent confirmation = new OrderConfirmationEvent(
                    order.getIdempotencyKey(),
                    order.getCustomerId(),
                    order.getProductId(),
                    order.getQuantity(),
                    newStatus
            );
            confirmationProducer.sendOrderConfirmationEvent(confirmation);

        } catch (Exception e) {
            log.error("Error processing payment-result event at offset={}: {}",
                    record.offset(), e.getMessage(), e);
            throw new RuntimeException("Failed to process payment-result event", e);
        }
    }
}
