package com.fnb.orderManagementService.controller;

import com.fnb.orderManagementService.dto.OrderRequest;
import com.fnb.orderManagementService.dto.OrderResponse;
import com.fnb.orderManagementService.service.OrderService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/orders")
@RequiredArgsConstructor
public class OrderController {

    private final OrderService orderService;

    @PostMapping
    public ResponseEntity<OrderResponse> createOrder(
            @RequestHeader(value = "Idempotency-Key", required = false) String idempotencyKey,
            @RequestBody OrderRequest request) {
        if (idempotencyKey != null) {
            request.setIdempotencyKey(idempotencyKey);
        }
        return ResponseEntity.ok(orderService.createOrder(request));
    }

    @PostMapping("/batch/{count}")
    public ResponseEntity<Map<String, Object>> createOrdersBatch(@PathVariable int count,
                                                                 @RequestBody OrderRequest request) {
        Instant start = Instant.now();
        List<OrderResponse> orders = orderService.createOrdersBatch(count, request);
        Instant end = Instant.now();
        long durationMs = end.toEpochMilli() - start.toEpochMilli();

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("startTime", start.toString());
        result.put("endTime", end.toString());
        result.put("durationMs", durationMs);
        result.put("count", orders.size());
        result.put("orders", orders);
        return ResponseEntity.ok(result);
    }

    @GetMapping
    public ResponseEntity<List<OrderResponse>> getAllOrders() {
        return ResponseEntity.ok(orderService.getAllOrders());
    }

    @GetMapping("/{id}")
    public ResponseEntity<OrderResponse> getOrderById(@PathVariable Long id) {
        return ResponseEntity.ok(orderService.getOrderById(id));
    }
}
