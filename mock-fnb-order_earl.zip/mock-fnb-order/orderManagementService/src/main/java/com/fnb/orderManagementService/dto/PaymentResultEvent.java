package com.fnb.orderManagementService.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class PaymentResultEvent {
    private String orderId;
    private String customerId;
    private String productId;
    private Integer quantity;
    private String status;
}
