package com.fnb.orderManagementService.repository;

import com.fnb.orderManagementService.entity.Order;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface OrderRepository extends JpaRepository<Order, Long> {
    List<Order> findByCustomerId(String customerId);

    Optional<Order> findByIdempotencyKey(String idempotencyKey);
}
