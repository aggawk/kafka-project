package com.fnb.orderManagementService.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class OrderEvent {
    @JsonProperty("order_id")
    private String orderId;
    private String user;
    private String item;
    private Integer quantity;
}
