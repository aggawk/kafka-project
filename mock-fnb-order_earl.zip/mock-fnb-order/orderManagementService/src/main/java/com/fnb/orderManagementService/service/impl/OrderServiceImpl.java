package com.fnb.orderManagementService.service.impl;

import com.fnb.orderManagementService.dto.OrderEvent;
import com.fnb.orderManagementService.dto.OrderRequest;
import com.fnb.orderManagementService.dto.OrderResponse;
import com.fnb.orderManagementService.entity.Order;
import com.fnb.orderManagementService.kafka.OrderEventProducer;
import com.fnb.orderManagementService.repository.OrderRepository;
import com.fnb.orderManagementService.service.OrderService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

@Service
@RequiredArgsConstructor
@Slf4j
public class OrderServiceImpl implements OrderService {

    private final OrderRepository orderRepository;
    private final OrderEventProducer orderEventProducer;

    @Override
    @Transactional
    public OrderResponse createOrder(OrderRequest request) {
        String idempotencyKey = request.getIdempotencyKey() != null
                ? request.getIdempotencyKey()
                : UUID.randomUUID().toString();

        // Return existing order if this key was already processed
        Optional<Order> existing = orderRepository.findByIdempotencyKey(idempotencyKey);
        if (existing.isPresent()) {
            log.info("Duplicate request detected for idempotencyKey={}, returning existing order", idempotencyKey);
            return toResponse(existing.get());
        }

        Order order = Order.builder()
                .idempotencyKey(idempotencyKey)
                .customerId(request.getCustomerId())
                .productId(request.getProductId())
                .quantity(request.getQuantity())
                .build();

        order = orderRepository.save(order);

        OrderEvent event = new OrderEvent(
                order.getIdempotencyKey(),
                order.getCustomerId(),
                order.getProductId(),
                order.getQuantity()
        );
        orderEventProducer.sendOrderCreatedEvent(event);

        return toResponse(order);
    }

    @Override
    public List<OrderResponse> createOrdersBatch(int count, OrderRequest request) {
        return IntStream.rangeClosed(1, count)
                .parallel()
                .mapToObj(i -> createOrder(request))
                .collect(Collectors.toList());
    }

    @Override
    public List<OrderResponse> getAllOrders() {
        return orderRepository.findAll().stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    @Override
    public OrderResponse getOrderById(Long id) {
        Order order = orderRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Order not found: " + id));
        return toResponse(order);
    }

    @Override
    @Transactional
    public void updateOrderStatus(Long orderId, String paymentStatus) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found: " + orderId));
        String newStatus = paymentStatus.equals("APPROVED") ? "COMPLETED" : "PAYMENT_DECLINED";
        if (newStatus.equals(order.getStatus())) {
            log.info("Order {} already in status {}, skipping update", orderId, newStatus);
            return;
        }
        order.setStatus(newStatus);
        orderRepository.save(order);
    }

    private OrderResponse toResponse(Order order) {
        return new OrderResponse(
                order.getId(),
                order.getCustomerId(),
                order.getProductId(),
                order.getQuantity(),
                order.getStatus(),
                order.getCreatedAt()
        );
    }
}
