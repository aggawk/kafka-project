package com.fnb.orderManagementService.kafka;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fnb.orderManagementService.dto.OrderEvent;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Component;

import java.util.concurrent.CompletableFuture;

@Component
@RequiredArgsConstructor
@Slf4j
public class OrderEventProducer {

    private final KafkaTemplate<String, String> kafkaTemplate;
    private final ObjectMapper objectMapper;
    private static final String TOPIC = "order-created";

    public void sendOrderCreatedEvent(OrderEvent event) {
        try {
            String message = objectMapper.writeValueAsString(event);
            String key = event.getUser();
            log.info("Publishing order-created event for user={}, orderId={}: {}", key, event.getOrderId(), message);

            CompletableFuture<SendResult<String, String>> future =
                    kafkaTemplate.send(TOPIC, key, message);

            future.whenComplete((result, ex) -> {
                if (ex != null) {
                    log.error("Failed to deliver order-created event for user={}: {}",
                            key, ex.getMessage(), ex);
                } else {
                    log.info("Order-created event delivered for user={}, partition={}, offset={}",
                            key,
                            result.getRecordMetadata().partition(),
                            result.getRecordMetadata().offset());
                }
            });
        } catch (Exception e) {
            log.error("Error serializing order-created event for orderId={}: {},",
                    event.getOrderId(), e.getMessage(), e);
            throw new RuntimeException("Failed to publish order event", e);
        }
    }
}
