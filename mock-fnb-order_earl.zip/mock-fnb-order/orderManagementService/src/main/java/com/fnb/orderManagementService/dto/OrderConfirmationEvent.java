package com.fnb.orderManagementService.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class OrderConfirmationEvent {
    private String orderId;
    private String user;
    private String item;
    private Integer quantity;
    private String status;
}
