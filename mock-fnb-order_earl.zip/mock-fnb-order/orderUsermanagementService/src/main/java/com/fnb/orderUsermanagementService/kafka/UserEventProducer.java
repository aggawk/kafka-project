package com.fnb.orderUsermanagementService.kafka;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Component;

import java.util.concurrent.CompletableFuture;

@Component
@RequiredArgsConstructor
@Slf4j
public class UserEventProducer {

    private final KafkaTemplate<String, String> kafkaTemplate;
    private static final String TOPIC = "user-registered";

    public void sendUserRegisteredEvent(String email) {
        log.info("Publishing user-registered event for: {}", email);

        CompletableFuture<SendResult<String, String>> future =
                kafkaTemplate.send(TOPIC, email, email);

        future.whenComplete((result, ex) -> {
            if (ex != null) {
                log.error("Failed to deliver user-registered event for {}: {}",
                        email, ex.getMessage(), ex);
            } else {
                log.info("User-registered event delivered for {}, partition={}, offset={}",
                        email,
                        result.getRecordMetadata().partition(),
                        result.getRecordMetadata().offset());
            }
        });
    }
}
