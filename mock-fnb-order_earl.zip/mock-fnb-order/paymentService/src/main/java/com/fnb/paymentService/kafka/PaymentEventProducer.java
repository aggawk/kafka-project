package com.fnb.paymentService.kafka;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fnb.paymentService.dto.PaymentResultEvent;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Component;

import java.util.concurrent.CompletableFuture;

@Component
@RequiredArgsConstructor
@Slf4j
public class PaymentEventProducer {

    private final KafkaTemplate<String, String> kafkaTemplate;
    private final ObjectMapper objectMapper;
    private static final String TOPIC = "payment-result";

    public void sendPaymentResultEvent(PaymentResultEvent event) {
        try {
            String message = objectMapper.writeValueAsString(event);
            String key = event.getOrderId();
            log.info("Publishing payment-result event for orderId={}: {}", key, message);

            CompletableFuture<SendResult<String, String>> future =
                    kafkaTemplate.send(TOPIC, key, message);

            future.whenComplete((result, ex) -> {
                if (ex != null) {
                    log.error("Failed to deliver payment-result event for orderId={}: {}",
                            key, ex.getMessage(), ex);
                } else {
                    log.info("Payment-result event delivered for orderId={}, partition={}, offset={}",
                            key,
                            result.getRecordMetadata().partition(),
                            result.getRecordMetadata().offset());
                }
            });
        } catch (Exception e) {
            log.error("Error serializing payment-result event for orderId={}: {}",
                    event.getOrderId(), e.getMessage(), e);
            throw new RuntimeException("Failed to publish payment-result event", e);
        }
    }
}
