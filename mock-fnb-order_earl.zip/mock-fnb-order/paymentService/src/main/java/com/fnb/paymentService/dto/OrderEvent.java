package com.fnb.paymentService.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class OrderEvent {
    @JsonProperty("order_id")
    private String orderId;
    private String user;
    private String item;
    private Integer quantity;
}
