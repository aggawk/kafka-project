package com.fnb.paymentService.kafka;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fnb.paymentService.dto.OrderEvent;
import com.fnb.paymentService.service.PaymentService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
@Slf4j
public class PaymentEventConsumer {

    private final PaymentService paymentService;
    private final ObjectMapper objectMapper;

    @KafkaListener(topics = "order-created", groupId = "payment-group")
    public void consumeOrderCreatedEvent(ConsumerRecord<String, String> record) {
        try {
            log.info("Payment service received order-created event: partition={}, offset={}, key={}",
                    record.partition(), record.offset(), record.key());
            OrderEvent event = objectMapper.readValue(record.value(), OrderEvent.class);
            paymentService.createPendingPayment(event);
        } catch (Exception e) {
            log.error("Error processing order-created event at offset={}: {}",
                    record.offset(), e.getMessage(), e);
            throw new RuntimeException("Failed to process order-created event", e);
        }
    }
}
