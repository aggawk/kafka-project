package com.fnb.orderInventoryManagementService.kafka;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fnb.orderInventoryManagementService.dto.OrderEvent;
import com.fnb.orderInventoryManagementService.service.InventoryService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
@Slf4j
public class InventoryEventConsumer {

    private final InventoryService inventoryService;
    private final ObjectMapper objectMapper;

    @KafkaListener(topics = "order-created", groupId = "inventory-group")
    public void consumeOrderCreatedEvent(ConsumerRecord<String, String> record) {
        try {
            log.info("Received order-created event: partition={}, offset={}, key={}",
                    record.partition(), record.offset(), record.key());
            OrderEvent event = objectMapper.readValue(record.value(), OrderEvent.class);
            inventoryService.deductInventoryIdempotent(event.getOrderId(), event.getItem(), event.getQuantity());
        } catch (Exception e) {
            log.error("Error processing order-created event at offset={}: {}",
                    record.offset(), e.getMessage(), e);
            throw new RuntimeException("Failed to process order-created event", e);
        }
    }
}
